package com.faheemtrading.exception;

public class AppException extends Exception {
    public AppException(String msg, Throwable cause){ super(msg, cause); }
}
